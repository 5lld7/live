<template functional>
  <h3 class="text-lg leading-6 font-medium text-gray-900">
    <slot />
  </h3>
</template>

<script>
  export default {
    name: 'ModalTitle',
  }
</script>
