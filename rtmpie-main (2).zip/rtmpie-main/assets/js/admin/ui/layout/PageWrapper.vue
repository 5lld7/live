<template>
  <main>
    <div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <slot />
    </div>
  </main>
</template>

<script>
  export default {
    name: 'PageWrapper',
  }
</script>
