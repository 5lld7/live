<template>
  <h1 class="text-3xl font-bold leading-tight text-gray-900">
    <slot />
  </h1>
</template>

<script>
  export default {
    name: 'PageTitle',
  }
</script>
