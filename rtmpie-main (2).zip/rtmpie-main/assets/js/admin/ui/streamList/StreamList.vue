<template>
  <div class="bg-white shadow overflow-hidden sm:rounded-md">
    <ul>
      <slot />
    </ul>
  </div>
</template>

<script>
  export default {
    name: 'StreamList',
  }
</script>
